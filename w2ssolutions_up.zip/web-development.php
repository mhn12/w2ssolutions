<?php include ("include/header.php"); ?>

<div id="content" class="webDevelop webdevelopmentPage">
		<div class="fullwidthbanner-container">
				<div class="fullwidthbanner">
                    <ul>
                    <li data-transition="fade">
                    <!--<div class="bannerBar banner2"></div>
                    <div class="caption title sft" data-x="-60"  data-y="110" data-speed="700" data-start="1500" data-easing="easeOutBack">Customized Janitorial Reporting Software <br />  for a leading Healthcare Center </div>
                    <div class="appTitle caption text sfl" data-x="-60"  data-y="240" data-speed="700" data-start="2500" data-easing="easeOutBack">Mark Heller</div>
                    <div class="caption text sfb" data-x="-60" data-y="300" data-speed="700" data-start="3000" data-easing="easeOutBack"> <div class="award-2"></div> </div>
                    <div class="caption fade" data-x="550" data-y="65" data-speed="700" data-start="700" data-easing="easeOutBack"> <div class="bannerImg-2"></div> </div>-->
                    <div class="webDevelopBannerImg-1"></div>
                    </li>
                    					
                    <li data-transition="fade">
                    <!--<div class="bannerBar banner3"></div>
                    <div class="caption title sft" data-x="-60" data-y="110" data-speed="700" data-start="1500" data-easing="easeOutBack"> Retail Sales Solution for a <br />well-known Shopping Mall.</div>
                    <div class="appTitle caption text sfl" data-x="-60" data-y="240" data-speed="700" data-start="2500" data-easing="easeOutBack">AGS</div>
                    <div class="caption text sfb" data-x="-60" data-y="300" data-speed="700" data-start="3000" data-easing="easeOutBack"> <div class="award-3"></div> </div>
                    <div class="caption fade" data-x="370"  data-y="115" data-speed="700" data-start="700" data-easing="easeOutBack"> <div class="bannerImg-3"></div> </div>-->
                    <div class="webDevelopBannerImg-2"></div>
                    </li>
                    </ul>
                    
                </div><!-- end .fullwidthbanner -->
            </div><!-- end .fullwidthbanner -->
            
            <div class="row subHead headline">
             <h1>Web Development</h1>
            <!--<p class="headerText">We make iPhone Apps that provides <br /> <b>great experiences!</b></p>-->
            <p>Our principles enable rapid and scalable development and deployment. We leverage Lean, Agile and Kanban principles to deliver unsurpassed quality in the shortest possible delivery time. Our principles also allow us to be extremely response to our Enterprise Customers and their Enterprise Applications.</p>
            <p>The Development Teams diverse knowledge in various programming languages creates benefits like productivity, lower development costs, and improved quality. Most programming languages have similar fundamental capabilities; however, some are better at solving certain tasks. We work with our Clients to determine a language based on need – and not how much money we get paid to develop.</p>
            </div>
            
           
          
            
          <div class="row">
            	<div class="span12">
                
                	<div id="tab-1">
                    
                        <ul class="tabs-menu fixed">
                            <li>
                                <a href="#content-tab-1-1">Microsoft </a>
                            </li>
                            <li>
                                <a href="#content-tab-1-2">PHP</a>
                            </li>
                            <li>
                                <a href="#content-tab-1-3">Jquery</a>
                            </li>
                        </ul><!-- end .tabs-menu -->
                        
                        <div class="tabs">
                            
                            <div class="tab-content" id="content-tab-1-1">
                            <p>We offer comprehensive custom application services that are highly scalable, user friendly and expedite your business outcome.  With the latest <a href="Dot-Net-Microsoft-web-application-developments">MVC framework</a> and Microsoft technologies our technical folks provide you the best solution that is built to adapt rather than following traditional strategy.  Our Dot Net developers are good in providing Innovative web solution that maximizes your business growth. </p>
                            <p>When it comes to Technology, digital media marketing, customer engagement, web analytics and moving to cloud are the core focus for any businesses. However Small and Medium enterprises are not ready to support these growth factors because lack of time and energy. </p>
                            <p>At W2S Solutions, our enterprise dot net development team addresses these challenges for SME’s by providing best solution that takes care of customer engagement, web and mobile analytics and host in cloud for easy ramp up. We help businesses to meet their innovation, create new revenue opportunities, increase performance with business process automation technology solution and run  daily activities with no technical hassle. </p>

                            <span class="clr"></span> 
                            <a class="viewMoreGallery fr" href="Dot-Net-Microsoft-web-application-development">Read More</a>
                            </div><!-- end .tab-content -->
                            
                            <div class="tab-content" id="content-tab-1-2">	
                            <p>Our <a href="php-mysql-web-application-development">PHP Development</a> team has the spirit of Innovation. Our developers takes up the challenge and their problem solving attitude helps clients to achieve expected business outcome easily. By reusing well-known progresses, templates and best practices, our PHP development team accelerates project execution, achieves results within the specified time frame. Our approach is to </p>
                            <ul>
                            <li>Start visioning the business process based on kanban model and expected business outcome. </li>
                            <li>Start evolving security requirements, compliance and own the accountability to deliver the whole IT system.</li>
                            <li>Based on business needs, we will consider various platforms such as Jquery development, prestashop ecommerce or Magento package. </li>
                            <li>Any lack of features in PHP based system will create an extremely tangible negative impact and we will resolve this initially by understanding your business needs. </li>
                            </ul>

                            <span class="clr"></span> 
                            <a class="viewMoreGallery fr" href="php-mysql-web-application-development">Read More</a> 
                                
                            </div><!-- end .tab-content -->
                            
                            <div class="tab-content" id="content-tab-1-3">	
                                
                            <p> At Way2Smile Solutions, we use fast and continuous development practices to execute a project seamlessly.  Here is our approach to deliver a project in a short span of time. </p>
                            <p> At way2smile solutions, we integrate testing into the development team.  By having QA resources to work with developers, they understood the responsibility of fixing an issue and can easily move to next module once it’s done. We use continuous development, integration and testing to ensure application stability.   </p>

                                
                            <span class="clr"></span> 
                            <a class="viewMoreGallery fr" href="jquery-ecommerce-web-application-development">Read More</a>
                            </div><!-- end .tab-content -->
                            
						</div><!-- end .tabs -->  
                    
                    </div>                   
                
                </div><!-- end .span12 -->
            </div><!-- end .row -->
            
            
            <?php include("include/contact_bar.php") ?>
            <div class="row">
            <div class="span6 progressBar">
                    <div class="fixed">
                    <div class="progress-bar-description">
                    Microsoft Web Development
                    <span style="left:87%">87%</span>
                    </div><!-- end .progress-bar-description -->
                    <div class="progress-bar"> 
                    <span class="progress-bar-outer" data-width="87"> 
                    <span class="progress-bar-inner"></span>
                    </span>
                    </div><!-- end .progress-bar -->
                    </div>
                    
                    <div class="fixed">
                    <div class="progress-bar-description">
                    PHP Development
                    <span style="left:85%">85%</span>
                    </div><!-- end .progress-bar-description -->
                    <div class="progress-bar"> 
                    <span class="progress-bar-outer" data-width="85"> 
                    <span class="progress-bar-inner"></span>
                    </span>
                    </div><!-- end .progress-bar -->
                    </div>
                    
                    <div class="fixed">
                    <div class="progress-bar-description">
                    SaaS based Solution
                    <span style="left:75%">75%</span>
                    </div><!-- end .progress-bar-description -->
                    <div class="progress-bar"> 
                    <span class="progress-bar-outer" data-width="75"> 
                    <span class="progress-bar-inner"></span>
                    </span>
                    </div><!-- end .progress-bar -->
                    </div>
                    
                    <div class="fixed">
                    <div class="progress-bar-description">
                    Products enhancements
                    <span style="left:80%">80%</span>
                    </div><!-- end .progress-bar-description -->
                    <div class="progress-bar"> 
                    <span class="progress-bar-outer" data-width="80"> 
                    <span class="progress-bar-inner"></span>
                    </span>
                    </div><!-- end .progress-bar -->
                    </div>
                    
                </div>
                
                
                <div class="span2 countBar">
                <div class="milestone">
                <div class="milestone-content">
                <span class="milestone-value" data-stop="175" data-speed="2000"></span><span>%</span>
                <div class="milestone-description">Team expansion 2014</div>
                </div>
                </div><!-- end .milestone -->
                </div><!-- end .span3 -->
				
               <div class="span2 countBar">
                <div class="milestone fixed">
                <div class="milestone-content">
                <span class="milestone-value" data-stop="45" data-speed="2000"></span><span>+</span>
                <div class="milestone-description">Satisfied Clients</div>
                </div>
                </div><!-- end .milestone -->
                </div>
                
                <div class="span2 countBar">
                <div class="milestone fixed">
                <div class="milestone-content">
                <span class="milestone-value" data-stop="12" data-speed="2000"></span><span>+ Years</span>
                <div class="milestone-description">Total IT Experience</div>
                </div>
                </div><!-- end .milestone -->
                <div class="span3"></div>
                </div>
                
                <span class="clr"></span>
            </div>
          <div class="divider single-line"></div>

          
           
            
           
           
           
            <?php include("include/portfolio.php") ?> 
           
           
           <?php include("include/testimonial.php") ?> <!-- end .box -->
            
           
           
           
            
           
        </div><!-- end #content -->
        
<?php include("include/footer.php"); ?>