<div class="productBar row">
<div id="client-logos-slider">
<h1 style="text-align:center">Our Clients</h1>
<span class="slideIcons slideIcons3"></span>
</div><!-- end #client-logos-slider -->
</div><!-- end .span12 -->