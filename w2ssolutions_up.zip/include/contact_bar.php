<div class="emailUsBar bg-parallax-1">
            <div class="row">            
            <div class="span4">
            <h1>Email us at </h1>
            <span class="emailAddress">info@way2smile.com</span>
            <ul>
            <li><a href="https://www.facebook.com/way2smileSolutionspvtltd" target="_blank" class="socialMediaIcons-1"></a></li>
            <li><a href="https://twitter.com/w2ssolutions" target="_blank" class="socialMediaIcons-2"></a></li>
            <li><a href="http://www.youtube.com/watch?v=MbmJLXT5C0U" target="_blank" class="socialMediaIcons-3"></a></li>
            <li><a href="http://www.pinterest.com/way2smile/" target="_blank" class="socialMediaIcons-4"></a></li>
            <li><a href="https://plus.google.com/100513502934104525715/posts" target="_blank" class="socialMediaIcons-5"></a></li>
            <li><a href="http://www.linkedin.com/company/w2s-solutions" target="_blank" class="socialMediaIcons-6"></a></li>
            </ul>
            </div>
            
            <div class="span4 contactInfo">
            <h1>Call Us Now </h1>
            <span class="callUsNo callUsNo1"> +1 954 678 8492</span>
            <span class="callUsNo"> +91 444 351 6331</span>
            </div>
            
            <div class="span4">
            <h1>Start Now </h1>
            <span class="getAQote"></span>
            </div>
            </div>
            </div>