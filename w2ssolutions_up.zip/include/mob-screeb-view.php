<section class="app_features row">
        <div class="BenefitsWrap">
        <div class="wedofrm_warper">
        <!--<div class="aligncenter wedo_atricle">
          <h1>Way2smile App Features</h1>
          <div class="wed_tagline"> We Offer Multiple Features for both iPhone Apps And Android Apps</div>
        </div>-->
        <div class="AppAccrodianWrap">
          <div class="PicturesText">
              <ul>
              <li class="clearfix first active"> 
              <!--<span class="Line1"></span> -->
              <span class="AccIcon Icon1"></span>
              <div class="txtWrap"> 
              <span class="AccHead">User Interface (UI)–Design:</span> 
              <span class="AccTxt FirstC" style="display: inline-block;">We create unique and sophisticated user experiences for easy and intuitive navigation and usage.</span> 
              </div>
              </li>
              
              <li class="clearfix"> 
              <!--<span class="Line2"></span> -->
              <span class="AccIcon Icon2"></span>
              <div class="txtWrap"> 
              <span class="AccHead">Location Based App:</span> 
              <span class="AccTxt" style="display: none;">We offer location based app, allowing to determine user’s current location by using GPS.</span> 
              </div>
              </li>
              
              <li class="clearfix"> 
              <!--<span class="Line3"></span> -->
              <span class="AccIcon Icon3"></span>
              <div class="txtWrap"> 
              <span class="AccHead">Cloud API Integration:</span> 
              <span class="AccTxt" style="display: none;">We integrate your app with web service back end API.  It can be a cloud API or Salesforce API or any CRMs.</span> 
              </div>
              </li>
              
              <li class="clearfix"> 
             <!-- <span class="Line4"></span> -->
              <span class="AccIcon Icon4"></span>
              <div class="txtWrap"> 
              <span class="AccHead">In App Purchase:</span> 
              <span class="AccTxt" style="display: none;">Integrate In app purchase feature, add-ons, subscriptions and payment gateways. Provides more convenient shopping experience!</span> 
              </div>
              
              </li>
              <li class="clearfix last"> 
              <!--<span class="Line5"></span> -->
              <span class="AccIcon Icon5"></span>
              <div class="txtWrap"> 
              <span class="AccHead">Mobile Analytics Integration:</span> 
              <span class="AccTxt" style="display:none;">Applying analytics to your Mobile App will have dramatic impact on your customers, loyalty, and helps to measure success of your strategy.</span> 
              </div>
              </li>
            </ul>
           </div>
           <div class="Pictures"> 
          <span class="pic1 mobscreen bgadded" data-img="url(/assets/image/location-service-2.png)" style="background:url(_content/index/mob_screen/screen-1.png) no-repeat;"></span>
          <span class="pic2 mobscreen bgadded" data-img="url(/assets/image/location-service-2.png)" style="background:url(_content/index/mob_screen/screen-2.png) no-repeat;"></span>
          <span class="pic3 mobscreen bgadded" data-img="url(/assets/image/location-service-2.png)" style="background:url(_content/index/mob_screen/screen-3.png) no-repeat;"></span>
          <span class="pic4 mobscreen bgadded" data-img="url(/assets/image/location-service-2.png)" style="background:url(_content/index/mob_screen/screen-4.png) no-repeat;"></span>
          <span class="iPhone mobscreen bgadded" data-img="url(/assets/image/location-service-2.png)" style=" background:url(_content/index/mob_screen/mob_screen-5.png) no-repeat;"></span> 
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </section>