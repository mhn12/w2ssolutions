<style>.textwhite{color: white;}</style>
<div id="layerslider" class="homeBanner" style="width:100%;height:500px;">
			<div class="ls-slide" data-ls="transition2d:1;timeshift:-1000;">
				<img src="_content/index/slider/banner_bg-1.jpg" class="ls-bg" alt="Slide background"/>
                
				<img class="ls-l" style="top:58%;left:70%;" data-ls="offsetxin:0;delayin:1720;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/bannerImg-2.png" alt="">
				
				<img class="ls-l" style="top:300px;left:126px;" data-ls="offsetxin:0;delayin:2920;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/award-2.png" alt="">
				

				<p class="ls-l" style="top:150px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;">Experience elegant development </p>
                
				<p class="ls-l" style="top:190px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;">excellence through our</p>
                
				<p class="ls-l appTitle" style="top:250px; left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:2000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% top 0;offsetxout:-400; ">
				Android Apps
				</p>
                
                <!--<div class="ls-l ls-linkto-4 arrowLeft" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;"></div>
                <div class="ls-l ls-linkto-2 arrowRight" data-ls="offsetxin:50;delayin:1000;offsetxout:50;"></div>	-->			

			<img class="ls-l ls-linkto-4 arrowLeft" style="top:260px;left:1%;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="sliderimages/left.png" alt="">
            <img class="ls-l ls-linkto-2 arrowRight" style="top:260px;left:99%;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="sliderimages/right.png" alt="">				
			</div>
            
            
			<div class="ls-slide" data-ls="transition2d:1;timeshift:-1000;">
				<img src="_content/index/slider/banner_bg-3.jpg" class="ls-bg" alt="Slide background"/>

				<img class="ls-l" style="top:50px;left:72%;" data-ls="offsetxin:0;delayin:1720;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/bannerImg-3.png" alt="">
				
				<img class="ls-l" style="top:300px;left:126px;" data-ls="offsetxin:0;delayin:2920;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/award-3.png" alt="">
				
				<p class="ls-l" style="top:150px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> Conquer the smartphone </p>
                
				<p class="ls-l" style="top:190px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> world with our </p>
				
                <p class="ls-l appTitle" style="top:250px; left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:2000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% top 0;offsetxout:-400; ">iPhone Apps</p>		

				<img class="ls-l ls-linkto-1 arrowLeft" style="top:260px;left:1%;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="sliderimages/left.png" alt="">
                <img class="ls-l ls-linkto-3 arrowRight" style="top:260px;left:99%;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="sliderimages/right.png" alt="">
			</div>
            
			<div class="ls-slide" data-ls="transition2d:1;timeshift:-1000;">
				<img src="_content/index/slider/banner_bg-4.jpg" class="ls-bg" alt="Slide background"/>
				<img class="ls-l" style="top:50px;left:75%;" data-ls="offsetxin:0;delayin:1720;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/bannerImg-4.png" alt="">
				
				<img class="ls-l" style="top:300px;left:126px;" data-ls="offsetxin:0;delayin:2920;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/award-4.png" alt="">
				
				<p class="ls-l" style="top:150px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> Deliver excellent engagement with </p>
				<p class="ls-l" style="top:190px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> our Enterprise Mobility </p>
				
                <p class="ls-l appTitle" style="top:250px; left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:2000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% top 0;offsetxout:-400; ">
				iPad Apps
				</p>				
		

				<img class="ls-l ls-linkto-2 arrowLeft" style="top:260px;left:1%;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="sliderimages/left.png" alt="">
                <img class="ls-l ls-linkto-4 arrowRight" style="top:260px;left:99%;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="sliderimages/right.png" alt="">				
			</div>
			
            <div class="ls-slide" data-ls="transition2d:1;timeshift:-1000;">
			<img src="_content/index/slider/banner_bg-2.jpg" class="ls-bg" alt="Slide background"/>
			<img class="ls-l" style="top:50px;left:73%;" data-ls="offsetxin:0;delayin:1720;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/bannerImg-1.png" alt="">
				
				<img class="ls-l" style="top:300px;left:126px;" data-ls="offsetxin:0;delayin:2920;easingin:easeInOutQuart;scalexin:0.7;scaleyin:0.7;offsetxout:-800;durationout:1000;" src="_content/index/slider/award-1.png" alt="">
				
				<p class="ls-l" style="top:150px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> Drive growth with our exceptional </p>
				
                <p class="ls-l" style="top:190px;left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:1500;easingin:easeOutElastic;rotatexin:-90;transformoriginin:50% top 0;offsetxout:-200;durationout:1000;"> cloud based </p>
				
                <p class="ls-l appTitle caption text sfl tp-caption start" style="top:250px; left:116px;" data-ls="offsetxin:0;durationin:2000;delayin:2000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% top 0;offsetxout:-400; "> Web Development </p>
				
                <img class="ls-l ls-linkto-4 arrowLeft" style="top:260px;left:1%;" data-ls="offsetxin:-50;delayin:1000;rotatein:-40;offsetxout:-50;rotateout:-40;" src="sliderimages/left.png" alt="">
                <img class="ls-l ls-linkto-1 arrowRight" style="top:260px;left:99%;" data-ls="offsetxin:50;delayin:1000;offsetxout:50;" src="sliderimages/right.png" alt="">				
			</div>
		</div>