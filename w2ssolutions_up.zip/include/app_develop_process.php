<div class="progressBar">
           <div class="headline"><h1>APP DEVELOPMENT PROCESS </h1></div>
           <ul>
           <li>
           <div class="progressImg-1"></div>
           <h2>Analyze<br />  &nbsp;</h2>
           <p><a href="http://w2ssolutions.com/">We</a> discuss the concept and purpose of your idea to develop a roadmap of potential users, market opportunity, and development cost.</p>
           </li>
           
           <li>
           <div class="progressImg-2"></div>
           <h2>Design Tool<br />  &nbsp;</h2>
           <p>Our App design team will create an industry leading prototype for your specific product. This is always an exciting time as your idea is in the beginning stages of its life.</p>
           </li>
           
           <li>
           <div class="progressImg-3"></div>
           <h2>Agile development & <br /> Integrate QA Testing</h2>
           <p>We use an Agile Development principle to quickly mature the App as development continues. We always test on live devices with real time data integration for easy analysis.</p>
           </li>
           
           <li>
           <div class="progressImg-4"></div>
           <h2>Evaluate & <br /> Analytics</h2>
           <p>We don’t develop a product and then disappear! It’s important to understand how your App is actually being used. We track user behaviours to maximize trends and functionality.</p>
           </li>
           
            </ul>
            </div>