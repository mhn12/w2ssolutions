<div class="parallax bg-parallax-1">
<div class="row">
<div class="span12">
<div class="process-builder four-items">
<ul class="fixed">
<li><span>1</span><div class="process-description"><h3>Analysis</h3></div></li>
<li><span>2</span><div class="process-description"><h3>Utilize Agility</h3></div></li>
<li><span>3</span><div class="process-description"><h3>Integrate Testing</h3></div></li>
<li><span>4</span><div class="process-description"><h3>Evaluate & Analytics</h3></div></li>
<li><span>5</span><div class="process-description"><h3>Launch </h3></div></li>
</ul></div></div></div></div>