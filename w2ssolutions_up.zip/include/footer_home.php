 <div id="footer" class="footer">
		
		<!-- /// FOOTER     ///////////////////////////////////////////////////////////////////////////////////////////////////////// -->
			<div id="footer-middle">
		
            <!-- /// FOOTER MIDDLE     ////////////////////////////////////////////////////////////////////////////////////////////// -->
    
                <div class="row">
                	<div class="span4" id="footer-middle-widget-area-1">
                    	
                        <div class="widget widget_recent_entries">
                        
                        <h4 class="widget-title">
                        	<i class="ifc-edit"></i>
                        	Recent news
                        </h4>
                    
                        <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/w2ssolutions" data-widget-id="335253077848379392">Tweets by @w2ssolutions</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                    </div><!-- end .widget_recent_entries -->
                        
                    </div><!-- end .span4 -->
                   <div class="span4" id="footer-middle-widget-area-2">
                    	
                        <div class="widget ewf_widget_contact_info">
                        
                        <h4 class="widget-title">
                        	<i class="ifc-email"></i>
                            Contact information
                        </h4>
                    	
                        <ul>
                        	<li>
                            	<i class="ifc-home"></i>
                                8585 Spicewood Springs Road, <br />
								# 1335, Austin, <br />
                        		Texas - 78759
                            </li>
                            <li>
                            	<i class="ifc-home"></i>
                                19, P.S. Tower,<br />
								Govindarajapuram 2nd Street, Adyar,<br />
                        		Chennai - 600020
                            </li>
                            <li>
                            	<i class="ifc-phone2"></i>
                                Phone: +1 954 678 8492<br />
                                Phone: +91 444 351 6331<br />
                            </li>
                            <li>
                            	<i class="ifc-email"></i>
                                Email: <a href="mailto:Info@Way2Smile.com">Info@Way2Smile.com</a>
                                </li>
                                <li>
                                <i class="ifc-globe_filled"></i>
                                Web: <a href="http://w2ssolutions.com/">www.w2ssolutions.com</a>
                            </li>
                        </ul>
                        
                    </div><!-- end .ewf_widget_contact_info -->
                        
                    </div><!-- end .span4 -->
                    
                    <div class="span4" id="footer-middle-widget-area-3">
                    	
                        <h4 class="widget-title">
                        	<i class="ifc-home"></i>
                            Our office location
                        </h4>
                        
                        <div class="widget widget_text">
                    
                            <div class="textwidget">
                                
                                <p><img class="responsive-img" src="_layout/images/map.png" alt=""></p> 
                                <p class=" text-center last"><a href="contacts">View on live map</a></p>
                                
                            </div><!-- end .textwidget -->
                    <div class="textwidget">
                    <span class=" space10"></span>
                    <div class="fixed">
                    <a href="https://www.facebook.com/way2smileSolutionspvtltd" target="_blank" class="facebook-icon social-icon"><i class="ifc-facebook"></i></a>
                    <a href="https://twitter.com/w2ssolutions" target="_blank" class="twitter-icon social-icon"><i class="ifc-twitter"></i></a>
                    <a href="http://www.pinterest.com/way2smile/" target="_blank" class="pinterest-icon social-icon"><i class="ifc-pinterest"></i></a>
                    <a href="https://plus.google.com/100513502934104525715/posts" target="_blank" class="googleplus-icon social-icon"><i class="ifc-google_plus"></i></a>
                    <a href="http://www.linkedin.com/company/w2s-solutions" target="_blank" class="linkedin-icon social-icon"><i class="ifc-linkedin"></i></a>
                    </div>
                    </div><!-- end .textwidget -->
                            
                        </div><!-- end .widget_text -->
                        
                    </div><!-- end .span4 -->
                </div><!-- end .row -->
                
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
    
            </div><!-- end #footer-middle -->
            
            <div id="footer-bottom">
		
            <!-- /// FOOTER bottom     ////////////////////////////////////////////////////////////////////////////////////////////// -->
				
                <div class="row">
                	<div class="span6" id="footer-bottom-widget-area-1">
                    	
                        <div class="widget widget_text">
                    
                            <div class="textwidget">
   
                               <p class="last"> Copyright @ 2014 By W2S Solutions pvt ltd. All rights reserved.</p>

                            </div><!-- end .textwidget -->
                            
                        </div><!-- end .widget_text -->
                        
                    </div><!-- end .span6 -->
                    <div class="span6" id="footer-bottom-widget-area-2">
                    	
                        <div class="widget widget_text">
                    
                            <div class="textwidget">
   
                                <p class="text-right last"><a href="terms_and-conditions.php">Terms of Use</a> | <a href="privacy_policy.php">Privicy Policy</a> | <a href="#">Site Map</a></p>

                            </div><!-- end .textwidget -->
                            
                        </div><!-- end .widget_text -->
                        
                    </div><!-- end .span6 -->
                </div><!-- end .row -->
                
            <!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
    
            </div><!-- end #footer-bottom -->
            
		<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->

		</div><!-- end #footer -->
		
	</div><!-- end #wrap -->

<script type="text/javascript">
                $.noConflict();
                </script>
    <!-- /// jQuery ////////  -->
	<script src="_layout/js/jquery-2.1.0.min.js"></script>-->
  
    <!-- /// ViewPort ////////  -->
	<script src="_layout/js/viewport/jquery.viewport.js"></script>
    
    <!-- /// Easing ////////  -->
	<script src="_layout/js/easing/jquery.easing.1.3.js"></script>

    <!-- /// SimplePlaceholder ////////  -->
	<script src="_layout/js/simpleplaceholder/jquery.simpleplaceholder.js"></script>

    <!-- /// Fitvids ////////  -->
    <script src="_layout/js/fitvids/jquery.fitvids.js"></script>
    
    <!-- /// Superfish Menu ////////  -->
	<script src="_layout/js/superfish/hoverIntent.js"></script>
    <script src="_layout/js/superfish/superfish.js"></script>
    
    <!-- /// Revolution Slider ////////  -->
    <script src="_layout/js/revolutionslider/pluginsources/jquery.themepunch.plugins.min.js"></script>
    <script src="_layout/js/revolutionslider/js/jquery.themepunch.revolution.min.js"></script>
    
    <!-- /// bxSlider ////////  -->
	<script src="_layout/js/bxslider/jquery.bxslider.min.js"></script>
    
   	<!-- /// Magnific Popup ////////  -->
	<script src="_layout/js/magnificpopup/jquery.magnific-popup.min.js"></script>
    
    <!-- /// Isotope ////////  -->
	<script src="_layout/js/isotope/isotope.pkgd.min.js"></script>
    <script src="_layout/js/isotope/imagesloaded.pkgd.min.js"></script>
    
    <!-- /// Parallax ////////  -->
	<script src="_layout/js/parallax/jquery.parallax.min.js"></script>

	<!-- /// EasyPieChart ////////  -->
	<script src="_layout/js/easypiechart/jquery.easypiechart.min.js"></script>
    
    <!-- /// Easy Tabs ////////  -->
    <script src="_layout/js/easytabs/jquery.easytabs.min.js"></script>	

    <!-- /// Form validate ////////  -->
    <script src="_layout/js/jqueryvalidate/jquery.validate.min.js"></script>
    
	<!-- /// Form submit ////////  -->
    <script src="_layout/js/jqueryform/jquery.form.min.js"></script>
    
    <!-- /// gMap ////////  -->
	<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
	<script src="_layout/js/gmap/jquery.gmap.min.js"></script>
	
	<!-- /// Chart ////////  -->
    <script src="_layout/js/chart/chart.js"></script>

	<!-- /// Custom JS ////////  -->
	<script src="_layout/js/plugins.js"></script>	
	<script src="_layout/js/scripts.js"></script>
    <script type="text/javascript"> xPageELEM =4;</script>
    <script src="_layout/js/alljs.js" type="text/javascript"></script>
    
	<script src="_layout/js/navbar.js" type="text/javascript"></script>
    <script src="_layout/js/navbar2.js" type="text/javascript"></script>
    <script src="_layout/js/waypoints.min.js" type="text/javascript"></script>
    <!--<script src="_layout/js/jquery-1.6.4.min.js" type="text/javascript"></script>-->

	<!-- LayerSlider stylesheet -->
	<link rel="stylesheet" href="_layout/js/layerslider/css/layerslider.css" type="text/css">
	<!-- External libraries: jQuery & GreenSock -->
	
	<script src="_layout/js/layerslider/js/greensock.js" type="text/javascript"></script>
	<!-- LayerSlider script files -->
	<script src="_layout/js/layerslider/js/layerslider.transitions.js" type="text/javascript"></script>
	<script src="_layout/js/layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
    
	
    	<!-- Initializing the slider -->
	<script>
		jQuery("#layerslider").layerSlider({
		autoStart: false,
			responsive: true,
			responsiveUnder: 1280,
			layersContainer: 1280,
			skin: 'noskin',
			hoverPrevNext: false,
			skinsPath: '../layerslider/skins/'
		});
	</script>

	

	<script type="text/javascript" src="_layout/js/Jquery-AnimateOneByOne-1.0.js"></script>
	<script type="text/javascript">
		$(window).load(function(){
	//		$('a.show').click(function(){
				$('.element').animateOneByOne({
			      css:{
			        opacity: '1'
			      },
			      duration: 450,
			      interval: 800,
			      callback: function(){
			        $('.show').fadeOut(400,function(){
			        	$('.hide').fadeIn(400);
			        });
			       
			      } 
			    });			
			//    return false;	
		//	});
			
			
			$('a.hide').click(function(){
				$('.element').animateOneByOne({
			      css:{
			        opacity: '0'
			      },
			      duration: 150,
			      interval: 0,
			      order: 'DESC',
			      callback: function(){
			        $('.hide').fadeOut(400,function(){
			        	$('.show').fadeIn(400);
			        });
			        
			      } 
			    });			
			    return false;	
			});
		
		});
		
		  function show(id) {
    document.getElementById(id).style.visibility = "visible";
  }
  function hide(id) {
    document.getElementById(id).style.visibility = "hidden";
  }
	</script>  
    
   
    
<style>
 #div1, #div2, #div3, #div4, #div5, #div6, #div7, #div8, #div9 {
   position: absolute;
  top: -50px;
color: white;
  z-index: 10;
color: white; background-color: gray;
  
  }
    #div1, #div2, #div3, #div4, #div5, #div6, #div7, #div8, #div9 {  
    visibility: hidden;  
  }
  
  #div1 span, #div2 span, #div3 span, #div4, #div5, #div6, #div7, #div8, #div9 span{
   
  margin-right: 0px;
  margin-top: 20px;
  margin-bottom: 20px;
  }

  #mapImg img{
  height: 100%;
	width: 100%;
  }
</style>
</body>
</html>

<!--<script type="text/javascript">
                $.noConflict();
                </script>
    <!-- /// jQuery ////////  
<script src="_layout/js/viewport/jquery.viewport.js"></script><script src="_layout/js/bxslider/jquery.bxslider.min.js"></script> <script src="_layout/js/magnificpopup/jquery.magnific-popup.min.js"></script><script src="_layout/js/easytabs/jquery.easytabs.min.js"></script>	<script src="_layout/js/plugins.js"></script><script src="_layout/js/scripts.js"></script> <script type="text/javascript"> xPageELEM =4;</script><script src="_layout/js/navbar2.js" type="text/javascript"></script><script src="_layout/js/layerslider/js/greensock.js" type="text/javascript"></script><script src="_layout/js/layerslider/js/layerslider.transitions.js" type="text/javascript"></script><script src="_layout/js/layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script><script>jQuery("#layerslider").layerSlider({autoStart: false,responsive: true,responsiveUnder: 1280,layersContainer: 1280,skin: 'noskin',hoverPrevNext: false/*,//skinsPath: '../layerslider/skins/'*/});</script><script type="text/javascript" src="_layout/js/Jquery-AnimateOneByOne-1.0.js"></script>	<script type="text/javascript">$(window).load(function(){/*$('a.show').click(function(){*/$('.element').animateOneByOne({css:{opacity: '1'},duration: 450,interval: 800,callback: function(){$('.show').fadeOut(400,function(){$('.hide').fadeIn(400);});} });/*return false;	});*/$('a.hide').click(function(){$('.element').animateOneByOne({css:{opacity: '0'},duration: 150,interval: 0,order: 'DESC',callback: function(){$('.hide').fadeOut(400,function(){$('.show').fadeIn(400);});} });return false;});});function show(id) {document.getElementById(id).style.visibility = "visible";}function hide(id) {document.getElementById(id).style.visibility = "hidden";}</script><style>#div1,#div2,#div3,#div4,#div5,#div6,#div7,#div8,#div9{position:absolute;top:-50px;z-index:10;color:#fff;background-color:gray;visibility:hidden}#div1 span,#div2 span,#div3 span,#div4,#div5,#div6,#div7,#div8,#div9 span{margin-right:0;margin-top:20px;margin-bottom:20px}#mapImg img{height:100%;width:100%}</style>
<script type="text/javascript">function openpopupvideo() {windowhandle=window.open("", "newwin", "height=550, width=550");windowhandle.document.write('<title>My Video</title>');windowhandle.document.write('<embed height="500" width="500" src="https://www.youtube-nocookie.com/v/MbmJLXT5C0U?hl=en_US&version=3" />');}</script>
    -->
	
</body>
</html>