<div class="row">
<div class="span12">
<div class="headline">
<h1>Portfolio</h1>
</div>
</div>

<div class="span3">
<div class="portfolio-item">
<div class="portfolio-item-preview">
<a href="#" class="portfolioImgBar"><img src="_content/index/portfolio/mob-c2c.jpg" alt="Card2Contact-W2SSolutions, Android App"></a>
<div class="portfolio-item-overlay">
<div class="portfolio-item-overlay-actions"><a class="magnificPopup-gallery portfolio-item-zoom" href="_content/index/portfolio/mob-c2c.jpg"><i class="ifc-zoom_in"></i></a>
</div>
</div>
</div>
<div class="portfolio-item-description">
<h4><a href="#">Card2Contact - Android App</a><span></span></h4>
</div>
</div>
</div>

<div class="span3">
<div class="portfolio-item">
<div class="portfolio-item-preview">
<a href="#" class="portfolioImgBar"><img src="_content/index/portfolio/web-culture.jpg" alt="The culture Builders Profiling Tool-W2SSolutions"></a>
<div class="portfolio-item-overlay">
<div class="portfolio-item-overlay-actions"><a class="magnificPopup-gallery portfolio-item-zoom" href="_content/index/portfolio/web-culture.jpg"><i class="ifc-zoom_in"></i></a></div>
</div>
</div>
<div class="portfolio-item-description">
<h4><a href="#">Culture Builders - Web App</a><span></span></h4>
</div>
</div>
</div>

<div class="span3">
<div class="portfolio-item">
<div class="portfolio-item-preview">
<a href="#" class="portfolioImgBar"><img src="_content/index/portfolio/mob-sparetime.jpg" alt="SpareTime - iPhone app, W2S Mobile Apps Services"></a>
<div class="portfolio-item-overlay">
<div class="portfolio-item-overlay-actions">
<a class="magnificPopup-gallery portfolio-item-zoom" href="_content/index/portfolio/mob-sparetime.jpg"><i class="ifc-zoom_in"></i></a>
</div>
</div>
</div>
<div class="portfolio-item-description">
<h4><a href="#">SpareTime - iPhone App</a><span></span></h4>
</div>
</div>
</div>

<div class="span3">
<div class="portfolio-item">
<div class="portfolio-item-preview">
<a href="#" class="portfolioImgBar"><img src="_content/index/portfolio/mob-spa.jpg" alt="Sugar Spa App, Web Development Services"></a>
<div class="portfolio-item-overlay">
<div class="portfolio-item-overlay-actions"><a class="magnificPopup-gallery portfolio-item-zoom" href="_content/index/portfolio/mob-spa.jpg"><i class="ifc-zoom_in"></i></a>
</div>
</div>
</div>
<div class="portfolio-item-description">
<h4><a href="#">Sugar Spa App - Hybrid App</a><span></span></h4>
</div>
</div>
</div>
<a class="btn  fr" href="product-portfolio">View more</a>
<span class="clr"></span>
<span class="space10"></span>
</div>
<span class="clr"></span>