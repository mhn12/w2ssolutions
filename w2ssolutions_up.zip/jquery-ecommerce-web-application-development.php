<?php include ("include/header.php"); ?>

<div id="content">
          <div id="page-header">
          <div class="row">
          <div class="span12">
          <i class="ifc-warning_shield"></i>
          <h3>Ecommerce & Jquery Development</h3>
          </div><!-- end .span12 -->
          </div><!-- end .row -->
          </div><!-- end #page-header -->
		
		
            
            <div class="row">
            <div class="span12">
           <p>At W2S, we use continuously utilize the latest development practices to deliver projects. We pride ourselves on our ability to deliver projects on time. Here is an example of one of our best practices: </p>
           
           <p>	We integrate testing and development at the same time. This allows our Quality Assurance Team work with our Developers to solve problems seamlessly together, so fixes can be made quickly and development can continue. This keeps the App stable and moving towards it target launch date.  Our Development Team is responsible for their code and the Apps stability when in production. Instead of doing a patch-fix, our developers are accountable to fix the issue properly and immediately. </p>


                  
                    
                </div><!-- end .span12 -->
            </div><!-- end .row -->
            
          
            
            
         
          
		</div><!-- end #content -->
<?php include("include/footer.php"); ?>